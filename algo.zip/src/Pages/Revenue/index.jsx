import ProtocolStats from "../../components/ProtocolStats";

function Revenue() {
  return (
    <>
      <ProtocolStats />
      <div>Revenue</div>
    </>
  );
}

export default Revenue;
