import ProtocolStats from "../../components/ProtocolStats";

function ManageStrategy() {
  return (
    <>
      <ProtocolStats />
      <section className="mx-auto max-w-6xl my-6 w-full px-5 xl:px-0">
        ManageStrategy
      </section>
    </>
  );
}

export default ManageStrategy;
