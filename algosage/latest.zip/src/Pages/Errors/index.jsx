export const Error0 = () => {
  return <div>Error page</div>;
};
