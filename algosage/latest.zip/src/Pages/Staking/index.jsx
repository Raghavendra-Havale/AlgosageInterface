import ProtocolStats from "../../components/ProtocolStats";

function Staking() {
  return (
    <>
      <ProtocolStats />
      <div>Staking</div>
    </>
  );
}

export default Staking;
